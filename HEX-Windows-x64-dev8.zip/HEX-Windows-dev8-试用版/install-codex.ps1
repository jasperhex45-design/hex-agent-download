$ErrorActionPreference = 'Stop'
try {
    $exe = Join-Path $PSScriptRoot 'HEX.exe'
    if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) { throw 'HEX.exe was not found. Extract the complete package first.' }
    $app = Get-Command codex -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -eq $app) { throw 'Codex CLI was not found. Install Codex CLI and ensure it is available in PATH.' }
    $raw = & $app.Source mcp list --json 2>$null
    if ($LASTEXITCODE -ne 0) { throw 'Could not read Codex MCP configuration. No changes were made.' }
    $servers = @(($raw -join "`n") | ConvertFrom-Json)
    if (@($servers | Where-Object { $_.name -match '(?i)^hex' }).Count -gt 0) {
        throw 'A HEX server already exists in Codex. No settings were overwritten; please review the existing installation.'
    }
    & $app.Source mcp add hex -- $exe mcp
    if ($LASTEXITCODE -ne 0) { throw 'Codex did not register the HEX server.' }
    Write-Output 'HEX registered. Restart Codex, open a new chat and ask to use HEX.'
    exit 0
} catch {
    Write-Output $_.Exception.Message
    exit 1
}
